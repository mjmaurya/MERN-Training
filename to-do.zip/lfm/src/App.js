import Main from './component/Main.js'

function App() {
  return (
    <div className="App">
        <Main/>
    </div>
  );
}

export default App;
